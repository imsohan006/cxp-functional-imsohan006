package com.speechify

/**
 * SSML (Speech Synthesis Markup Language) is a subset of XML specifically
 * designed for controlling synthesis. You can see examples of how the SSML
 * should be parsed in [com.speechify.SSMLTest] in `src/test/kotlin/Ssml.test.kt`.
 *
 * You may:
 *  - Read online guides to supplement information given in [com.speechify.SSMLTest] to understand SSML syntax.
 * 
 * You must not:
 *  - Use XML parsing libraries or the DocumentBuilderFactory. The task should be solved only using string manipulation.
 *  - Read guides about how to code an XML or SSML parser.
 */

/**
 * Parses SSML to a SSMLNode, throwing on invalid SSML
 */
fun parseSSML(ssml: String): SSMLNode {
  // NOTE: Don't forget to run unescapeXMLChars on the SSMLText
  //TODO("Implement this function")
  unescapeXMLChars(ssml)

}

/**
 * Extracts all the human-readable plain-text contained in an SSML node
 */
fun ssmlNodeToText(node: SSMLNode): String {
  TODO("Implement this function")
  
}

// Already done for you
fun unescapeXMLChars(text: String) =
  text.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")

// SSMLNode is a sealed class, which can be either a SSMLTag or a SSMLText
sealed class SSMLNode

data class SSMLElement(
  val name: String,
  val attributes: List<SSMLAttribute>,
  val children: List<SSMLNode>
) : SSMLNode()



data class SSMLAttribute(
  val name: String,
  val value: String
)

// SSMLText is a type alias for String
data class SSMLText(val text: String): SSMLNode()

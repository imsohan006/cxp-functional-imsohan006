package com.speechify
/**
 * A Least Recently Used (LRU) cache is a type of cache that, when a need arises to constrain its size, evicts the
 * items whose last use was the furthest in the past.
 *
 * For this particular implementation, the size constraint is set at [CacheLimits.maxItemsCount].
 * An item is considered accessed whenever `get`, or `set` methods are called with its key.
 *
 * This LRU cache should ensure the constraint by checking the cache size at the time of each new insertion.
 * In the case where the cache has reached its limit, the item "least recently accessed" will be removed.
 * The implementation should be performant when storing big number of items.
 * It is OK for the removal of items to happen in the same thread that called the function (OK to block the return from
 * the function for a cleanup, when necessary).
 *
 * Tests are provided in [com.speechify.LRUCacheProviderTest] (`src/test/kotlin/LruCache.test.kt`) to validate your
 * implementation.
 *
 * You may:
 *  - Read online API references for Kotlin standard library or JVM collections.
 * You must not:
 *  - Read guides about how to code an LRU cache.
 */
interface LRUCache<T> {
  fun get(key: String): T?
  fun set(key: String, value: T)
}

data class CacheLimits(
  /**
   * @property maxItemsCount
   * Maximum count of items (*inclusive*) that this cache is allowed to contain.
 */
  val maxItemsCount: Int
  var cacheMap: LinkedHashMap<String, T>
)


fun <T> createLRUCache(options: CacheLimits): LRUCache<T> {
  //TODO("Implement LRU cache")
  CacheLimits(options, LinkedHashMap<String, T>());

  // AS I DON"T KNOW MUCH ABOUT KOTLIN IT'S TAKING MORE TIME

  //APPROCH : Using map we can solve this by redefining key place in map whenever we call get or set function
               // There might be syntext error so you can consider it as more like sudo code.
               // I have more optimize if this in in java as with kotlin i need to see it's syntex everytime which is taking time.
}

fun <T> get(String: key): LRUCache<T> {
  var lruCacheMap: LinkedHashMap<String, Object> = CacheLimits.map;
  if(lruCacheMap.containsKey(key)) {
    val value = lruCacheMap.get(key);
    lruCacheMap.remove(key)
    lruCacheMap.put(key, value);
    return value
  };
  return null;
}

fun <T> set(String: key, T: value): LRUCache<T> {
  val capacity: int = CacheLimits.maxItemsCount;
  var lruCacheMap: LinkedHashMap<String, Object> = CacheLimits(map);
  if(lruCacheMap.containsKey(key)) {
    lruCacheMap.remove(key);
  } else if(capacity == lruCacheMap.size){
    var keys = lruCacheMap.keys;
    for(key in keys) {
      lruCacheMap.remove(key);
      break;
    }
  }
  lruCacheMap.put(key, value);
  return value;
}

rootProject.name = "platform-kotlin"

